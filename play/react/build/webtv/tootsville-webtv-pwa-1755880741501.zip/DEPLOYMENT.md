# Tootsville Web TV Deployment Instructions

## Build Type: PWA

### PWA Deployment
1. Upload all files to your web server
2. Ensure HTTPS is enabled
3. Configure service worker caching
4. Test offline functionality

### WebView Deployment
1. Follow platform-specific instructions in the webview/ directory
2. Build native app using platform SDK
3. Package and distribute through app stores

### Capacitor Deployment
1. Run 'npm install' in the capacitor/ directory
2. Run 'npm run sync' to sync web assets
3. Run 'npm run webtv' to open in platform IDE
4. Build and deploy through platform-specific process

## Platform-Specific Notes


- Optimized for 1080p displays
- Supports Roku remote and gamepad input
- Roku Channel Store distribution
    

## Support

For technical support, contact Interworldly Adventuring, LLC at https://interworldly.com/